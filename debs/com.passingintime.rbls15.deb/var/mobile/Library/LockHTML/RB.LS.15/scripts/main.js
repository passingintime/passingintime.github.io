function updateClock() { 
var d = new Date();
var g = d.getDate();
var currentHours = d.getHours();
var currentMinutes = d.getMinutes() < 10 ? '0' + d.getMinutes() : d.getMinutes();
var currentSeconds = d.getSeconds() < 10 ? '0' + d.getSeconds() : d.getSeconds();
var date = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
var months= ["Jan","Feb","Mar","Apr","May","June","July","Aug","Sep","Oct","Nov","Dec"];

if (Clock == "24h") {
	timeOfDay = "";
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	dString = currentHours + ":" + currentMinutes;
       document.getElementById("clock").innerHTML = currentHours + ":" + currentMinutes;
	}
if (Clock == "12h") {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	dString = currentHours + ":" + currentMinutes;
       document.getElementById("clock").innerHTML = currentHours + ":" + currentMinutes;
}

if (d.getDay() == 0) {
	document.getElementById("d1-y").innerHTML = days[d.getDay() +6];
}else if (d.getDay() == 7){
	document.getElementById("d1-y").innerHTML = days[d.getDay() -6];
}else {
	document.getElementById("d1-y").innerHTML = days[d.getDay() -1];
}

document.getElementById("d1-td").innerHTML = days[d.getDay()];

if (d.getDay() == 6) {
	document.getElementById("d1-tm").innerHTML = days[d.getDay() -6];
}else {
	document.getElementById("d1-tm").innerHTML = days[d.getDay() +1];
}


document.getElementById("d2-y").innerHTML = months[d.getMonth()] + " " + date[d.getDate() -1];

document.getElementById("d2-td").innerHTML = months[d.getMonth()] + " " + date[d.getDate()];



if (((d.getMonth() == 3 || d.getMonth() == 5 || d.getMonth() == 8 || d.getMonth() == 10) && d.getDate() == 30)) {
	document.getElementById("d2-tm").innerHTML = months[d.getMonth() +1] + " " + date[d.getDate() -29];
}else if (((d.getMonth() == 0 || d.getMonth() == 2 || d.getMonth() == 4 || d.getMonth() == 6 || d.getMonth() == 7 || d.getMonth() == 9 || d.getMonth() == 11) && d.getDate() == 31)) {
	document.getElementById("d2-tm").innerHTML = months[d.getMonth() +1] + " " + date[d.getDate() -30];
}else {
	document.getElementById("d2-tm").innerHTML = months[d.getMonth()] + " " + date[d.getDate() +1];
}

}

function bgg() {
if (brightbackground == "true") {
document.getElementById('body').style.background = "linear-gradient(rgba(51,51,51,0.5),rgba(51,51,51,0))";
}else {
document.getElementById('body').setAttribute("background" , "transparent");
}

}

function initC(){
bgg();
updateClock();
setInterval("updateClock();", 1000);
}