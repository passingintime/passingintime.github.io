var Clock = "12h";	       // choose between "12h" or "24h".

var brightbackground = 'true';

var weathercode = '32225';
var celsius = false;
var gpsswitch = false;
var refreshrate = 1;

miniWeather({
        code : weathercode,
        temp : celsius,
        lang : 'en',
        gps : gpsswitch, //must use widget weather xml if set to true
        refresh : refreshrate, // in minutes
        success: function(w){
                document.getElementById('city').innerHTML = w.city;
				document.getElementById('temp').innerHTML = w.temp + '&deg;';
				document.getElementById('weatherIcon').src = 'images/weather/' + w.icon + '.png';
        }
});