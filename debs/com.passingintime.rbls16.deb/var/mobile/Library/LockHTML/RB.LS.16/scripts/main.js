function updateClock() { 
var d = new Date();
var g = d.getDate();
var currentHours = d.getHours();
var currentMinutes = d.getMinutes() < 10 ? '0' + d.getMinutes() : d.getMinutes();
var currentSeconds = d.getSeconds() < 10 ? '0' + d.getSeconds() : d.getSeconds();
var date = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
var months= ["Jan","Feb","Mar","Apr","May","June","July","Aug","Sep","Oct","Nov","Dec"];

if (Clock == "24h") {
	timeOfDay = "";
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	dString = currentHours + ":" + currentMinutes;
       document.getElementById("clock").innerHTML = currentHours + ":" + currentMinutes;
	}
if (Clock == "12h") {
	currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;
	currentHours = ( currentHours == 0 ) ? 12 : currentHours;
	dString = currentHours + ":" + currentMinutes;
       document.getElementById("clock").innerHTML = currentHours + ":" + currentMinutes;
}

document.getElementById("date").innerHTML = days[d.getDay()] + " " + months[d.getMonth()] + " " + d.getDate();

}

function bgg() {
if (brightbackground == "true") {
document.getElementById("body").style.background = "linear-gradient(rgba(51,51,51,0.5),rgba(51,51,51,0))";
}else {
document.getElementById("body").style.background= "none";
}

}

function initC(){
bgg();
updateClock();
setInterval("updateClock();", 1000);
}