var Clock = "12h";	       // choose between "12h" or "24h".

var brightbackground = 'true';

var weathercode = '32225';
var celsius = false;
var gpsswitch = false;
var refreshrate = 1;

miniWeather({
        code : weathercode,
        temp : celsius,
        lang : 'en',
        gps : gpsswitch, //must use widget weather xml if set to true
        refresh : refreshrate, // in minutes
        success: function(w){
				document.getElementById('temp').innerHTML = "Temp: " + w.temp + '&deg;';
        }
});