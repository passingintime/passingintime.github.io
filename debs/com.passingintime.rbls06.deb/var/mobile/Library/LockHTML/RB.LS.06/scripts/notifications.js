window.addEventListener("load", function() { 
    document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

function notif(){
    if (groovyAPI.isShowingNotifications()){
        $('#Clock').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Cal').animate({opacity: '0'}, 500);
        $('#weekday').animate({opacity: '0'}, 500);
        $('#Weather').animate({opacity: '0'}, 500);
        $('#cityname').animate({opacity: '0'}, 500);
        $('#weatherIcon').animate({opacity: '0'}, 500);
        $('#R').animate({'margin-top': '16%',}, 500);
        $('#C').animate({opacity: '0'}, 500);
    } else {
        $('#Clock').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Cal').animate({opacity: '1'}, 500);
        $('#weekday').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#weekday').animate({opacity: '1'}, 500);
        $('#Weather').animate({opacity: '1'}, 500);
        $('#cityname').animate({opacity: '1'}, 500);
        $('#weatherIcon').animate({opacity: '1'}, 500);
        $('#R').animate({'margin-top': '0%',}, 500);
        $('#C').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#C').animate({opacity: '0.2'}, 500);
    }

    setTimeout(notif, 1000);      
};

notif();